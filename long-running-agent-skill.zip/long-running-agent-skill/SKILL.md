---
name: long-running-agent
description: Framework for multi-session AI agent projects that span hours or days. Implements structured state artifacts (feature_list.json, claude-progress.txt, init.sh), session bootstrap protocols, and clean handover patterns. Use when building complex systems requiring work across multiple context windows—full-stack apps, trading systems, data pipelines, or any project too large for single-session completion.
---

# Long-Running Agent Framework

A systematic approach to agent work that spans multiple context windows. Treats sessions like shift handovers between engineers with complete amnesia.

## When to Use This Skill

Use this skill when:
- Project requires more than one session to complete
- User asks to "build", "create", or "develop" something complex
- Estimated work exceeds 1-2 hours of implementation
- Project has 10+ distinct features or requirements
- User explicitly mentions "long-running", "multi-session", or "continue later"

Do NOT use for:
- Simple scripts or single-file utilities
- Quick fixes or modifications
- Research or analysis tasks
- One-off questions

## Core Principle

**You have complete amnesia between sessions. The only continuity is through files.**

Every session must:
1. READ state files before doing anything
2. EXECUTE one incremental unit of work
3. WRITE updated state files
4. LEAVE environment in clean, working state

## Two-Phase Architecture

### Phase 1: Initializer Session

Run ONCE at project start. Creates all state artifacts.

```
Initializer Checklist:
[ ] Analyze requirements exhaustively
[ ] Create feature_list.json with ALL features (passes: false)
[ ] Create claude-progress.txt with session 1 entry
[ ] Create init.sh customized for tech stack
[ ] Create .gitignore
[ ] Make initial git commit
[ ] Verify init.sh runs (even if it just reports "no code yet")
```

### Phase 2: Coding Sessions

Run for ALL subsequent sessions. Makes incremental progress.

```
Coding Session Checklist:

START:
[ ] pwd - confirm directory
[ ] cat claude-progress.txt - read handover notes
[ ] cat feature_list.json - see what's pending
[ ] git log --oneline -10 - verify state
[ ] ./init.sh - start environment
[ ] Run basic test - verify app works BEFORE changes

WORK:
[ ] Pick ONE feature where passes=false
[ ] Implement completely with error handling
[ ] Test END-TO-END (not just unit tests)

END:
[ ] Update feature_list.json (only passes and verified_at fields)
[ ] Append session summary to claude-progress.txt
[ ] git commit -m "feat(FXXX): description"
[ ] Verify app still works
[ ] Write handover notes for next session
```

## State Artifacts

Every project maintains exactly three files at root:

### 1. feature_list.json

Structured requirements with pass/fail tracking.

```json
{
  "project_name": "My Project",
  "created": "2025-01-15T10:00:00Z",
  "last_updated": "2025-01-15T14:30:00Z",
  "total_features": 20,
  "passing_features": 5,
  "features": [
    {
      "id": "F001",
      "category": "functional",
      "priority": "critical",
      "description": "User can create account with email/password",
      "steps": [
        "Navigate to /register",
        "Enter valid email and password",
        "Click submit",
        "Verify account created and logged in"
      ],
      "dependencies": [],
      "passes": false,
      "verified_at": null,
      "notes": ""
    }
  ]
}
```

**Rules for feature_list.json:**
- NEVER remove features
- NEVER edit feature descriptions
- ONLY modify: `passes`, `verified_at`, `notes`, `last_updated`
- Add new features only if scope explicitly expands

**Why JSON?** Models are less likely to corrupt structured data. Markdown checkboxes invite freeform editing → drift.

### 2. claude-progress.txt

Human-readable session log with handover notes.

```markdown
# Claude Progress Log

## Project: My Project
## Repository: git@github.com:user/repo.git
## Primary Tech: React + FastAPI + PostgreSQL

---

## Session 3 - 2025-01-16 09:15 UTC

### Context Inherited
- Last commit: a1b2c3d - "feat(F005): user profile page"
- Features passing: 5/20
- Known issues: Rate limiting not working

### Session Goal
- F006: Password reset flow

### Work Completed
1. Created password reset endpoint
2. Added email sending via SendGrid
3. Built reset form UI
4. Added token expiration (1 hour)

### Testing Performed
- [x] App started with ./init.sh
- [x] Existing features still work
- [x] Password reset email sends
- [x] Reset link works and updates password
- [x] Expired tokens rejected

### Issues Encountered
- SendGrid API key needed - added to .env.example
- Token generation was weak - switched to secrets.token_urlsafe

### Files Changed
- `backend/routes/auth.py` - added reset endpoints
- `backend/services/email.py` - new file for email
- `frontend/src/pages/ResetPassword.tsx` - new page
- `.env.example` - added SENDGRID_API_KEY

### Commits Made
- a1b2c3d - "feat(F006): password reset flow"

### Handover Notes for Next Session
- **Priority**: F007 - Email verification
- **Blockers**: None
- **Warnings**: Need real SendGrid key for production
- **Environment state**: Clean, all tests pass

---
```

### 3. init.sh

One-command environment startup.

```bash
#!/bin/bash
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

echo "🔄 Initializing development environment..."

# Kill stale processes
for port in 3000 5173 8000; do
    lsof -ti:$port 2>/dev/null | xargs kill -9 2>/dev/null || true
done

# Backend
cd backend
source venv/bin/activate 2>/dev/null || python3 -m venv venv && source venv/bin/activate
pip install -q -r requirements.txt
uvicorn main:app --port 8000 --reload > /tmp/backend.log 2>&1 &
cd ..

# Frontend  
cd frontend
npm install --silent
npm run dev > /tmp/frontend.log 2>&1 &
cd ..

# Wait for ready
sleep 3
echo "✅ Ready: http://localhost:5173 (frontend) http://localhost:8000 (backend)"
```

## Feature ID Conventions

| Range | Category | Examples |
|-------|----------|----------|
| F001-F099 | Core functionality | Auth, CRUD, business logic |
| F100-F199 | Integrations | APIs, webhooks, third-party |
| F200-F299 | UI/UX | Pages, components, styling |
| F300-F399 | Performance | Caching, optimization |
| F400-F499 | Security | Encryption, validation |
| F500+ | Infrastructure | Deployment, monitoring |

## Priority Levels

- `critical` - MVP blocker, do first
- `high` - Production requirement
- `medium` - Important enhancement
- `low` - Nice to have

## Testing Requirements

**Claude tends to mark features complete without proper testing.** Force yourself to:

1. **Before implementing**: Run basic e2e test to verify app isn't broken
2. **After implementing**: Test as a user would
3. **Only mark passes: true** after visual/functional verification

For web apps:
- Actually navigate to pages
- Fill real forms
- Click real buttons
- Verify data persists
- Check error states

Unit tests are NOT sufficient for marking a feature complete.

## Common Failure Modes

| Problem | Cause | Prevention |
|---------|-------|------------|
| Agent builds everything at once | No constraints | Initializer creates feature list; coding agent picks ONE |
| Declares victory early | No verification | Must test e2e before passes=true |
| Leaves broken state | No discipline | Test before AND after changes |
| Next session confused | Poor handover | Mandatory progress file update |
| Features change over time | Editing descriptions | JSON structure prevents this |
| Scope creep | Adding features freely | Only add if explicitly requested |

## Initializer Session Template

When starting a new project, execute in order:

```python
# 1. Analyze the prompt
# Extract ALL implied features, even obvious ones

# 2. Create feature_list.json
# - Be exhaustive (20-50 features for complex projects)
# - All passes: false
# - Group by category
# - Set realistic priorities

# 3. Create init.sh
# - Customize for actual tech stack
# - Kill processes on needed ports
# - Install dependencies
# - Start all servers
# - Health check

# 4. Create claude-progress.txt
# - Session 1 entry
# - Document decisions made
# - Handover notes for session 2

# 5. Create .gitignore
# - Standard ignores for tech stack
# - Database files
# - Environment files
# - IDE files

# 6. Git commit
git add .
git commit -m "Initial project scaffold

Session: 1 (Initializer)
Features: X total, 0 passing

Next: F001 - [first feature]"
```

## Coding Session Template

Every non-initial session:

```bash
# === START ===
pwd
cat claude-progress.txt
cat feature_list.json | head -100  # Or use jq if available
git log --oneline -10
./init.sh

# Verify app works before touching code
curl http://localhost:8000/health  # or appropriate test

# === WORK ===
# Pick ONE feature
# Implement fully
# Test end-to-end

# === END ===
# Update feature_list.json
# Append to claude-progress.txt
git add .
git commit -m "feat(F00X): description

Session: N
Features: X/Y passing"
```

## Integration with Other Skills

This skill works well with:

- **specification-architect**: Use for initial requirements gathering → this skill for execution
- **ai-driven-dev-workflow**: Same principles, extended for session boundaries
- **equity-research-analyst**: For trading system projects
- **frontend-design**: For UI-heavy features

## Quick Reference Card

```
┌─────────────────────────────────────────────────┐
│            LONG-RUNNING AGENT RULES             │
├─────────────────────────────────────────────────┤
│                                                 │
│  START: Read progress → Read features → init.sh │
│                                                 │
│  WORK:  ONE feature → Implement → Test e2e     │
│                                                 │
│  END:   Update JSON → Update progress → Commit │
│                                                 │
├─────────────────────────────────────────────────┤
│  ✓ One feature per session                     │
│  ✓ Test before marking done                    │
│  ✓ Leave code working                          │
│  ✓ Write handover notes                        │
│  ✗ Never edit feature descriptions             │
│  ✗ Never skip the checklist                    │
└─────────────────────────────────────────────────┘
```

## Files in This Skill

- `SKILL.md` - This file
- `references/templates.md` - Full file templates
- `references/examples.md` - Example projects and sessions
- `scripts/init_project.py` - Project scaffolding script
- `templates/` - Starter templates for state files
