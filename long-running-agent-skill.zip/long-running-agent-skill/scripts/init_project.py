#!/usr/bin/env python3
"""
Initialize a new long-running agent project with required artifacts.

Usage:
    python init_project.py <project_name> [--path <output_dir>] [--tech <stack>]
    
Examples:
    python init_project.py my-webapp
    python init_project.py trading-bot --path ~/projects --tech python
    python init_project.py saas-app --tech nextjs
"""

import argparse
import json
import os
import stat
from datetime import datetime, timezone
from pathlib import Path


TECH_STACKS = {
    "react-fastapi": {
        "description": "React + Vite frontend, FastAPI backend",
        "ports": [5173, 8000],
        "frontend_cmd": "npm run dev",
        "backend_cmd": "uvicorn main:app --reload --port 8000",
    },
    "nextjs": {
        "description": "Next.js 14 full-stack",
        "ports": [3000],
        "frontend_cmd": "npm run dev",
        "backend_cmd": None,
    },
    "python": {
        "description": "Python CLI or service",
        "ports": [8000],
        "frontend_cmd": None,
        "backend_cmd": "python main.py",
    },
    "node": {
        "description": "Node.js/Express backend",
        "ports": [3000],
        "frontend_cmd": None,
        "backend_cmd": "npm run dev",
    },
}


def create_feature_list(project_name: str) -> dict:
    """Create initial feature_list.json structure."""
    now = datetime.now(timezone.utc).isoformat()
    return {
        "project_name": project_name,
        "created": now,
        "last_updated": now,
        "total_features": 2,
        "passing_features": 0,
        "categories": {
            "functional": "Core user-facing functionality",
            "integration": "External system connections",
            "ui": "User interface and experience",
            "performance": "Speed and scalability requirements",
            "security": "Authentication, authorization, data protection",
            "infrastructure": "Deployment, monitoring, logging"
        },
        "features": [
            {
                "id": "F001",
                "category": "infrastructure",
                "priority": "critical",
                "description": "Development server starts and responds to health check",
                "steps": [
                    "Run ./init.sh",
                    "Server starts without errors",
                    "Health endpoint returns 200 OK"
                ],
                "dependencies": [],
                "passes": False,
                "verified_at": None,
                "notes": ""
            },
            {
                "id": "F002",
                "category": "infrastructure",
                "priority": "critical",
                "description": "Project structure created with all dependencies",
                "steps": [
                    "All config files present",
                    "Dependencies install successfully",
                    "Linter/formatter passes"
                ],
                "dependencies": [],
                "passes": False,
                "verified_at": None,
                "notes": ""
            }
        ]
    }


def create_progress_file(project_name: str, tech_stack: str) -> str:
    """Create initial claude-progress.txt content."""
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
    tech_info = TECH_STACKS.get(tech_stack, TECH_STACKS["react-fastapi"])
    
    return f"""# Claude Progress Log

## Project: {project_name}
## Repository: [TODO: Add git remote URL]
## Primary Tech: {tech_info['description']}

---

## Session 1 - {timestamp} UTC (Initializer)

### Session Type
Initializer session - project scaffolding

### Work Completed
1. Created project structure
2. Generated initial feature_list.json with starter features
3. Created init.sh startup script for {tech_stack} stack
4. Initialized git repository

### Tech Stack Decisions
- Stack: {tech_stack}
- Ports: {', '.join(str(p) for p in tech_info['ports'])}

### Files Created
- `feature_list.json` - Feature tracker (2 starter features)
- `claude-progress.txt` - This file
- `init.sh` - Development startup script
- `.gitignore` - Standard ignores

### Commits Made
- [initial] - "Initial project scaffold"

### Handover Notes for Next Session
- **Priority**: Expand feature_list.json with ALL project requirements
- **Blockers**: None
- **Warnings**: Feature list needs expansion before implementation begins
- **Environment state**: Clean scaffold only - no app code yet
- **Next steps**: 
  1. Add all features to feature_list.json
  2. Create actual app structure (backend/, frontend/, etc.)
  3. Implement F001 and F002

---

<!-- 
SESSION TEMPLATE - Copy for each new session:

## Session N - YYYY-MM-DD HH:MM UTC

### Context Inherited
- Last commit: [hash] - "[message]"
- Features passing: X/Y
- Known issues: [list]

### Session Goal
- [Feature ID]: [Description]

### Work Completed
1. [What you did]

### Testing Performed
- [x] App started with ./init.sh
- [x] Existing features verified
- [x] New feature tested e2e

### Issues Encountered
- [Issue] → [Resolution]

### Files Changed
- `path/file` - [changes]

### Commits Made
- [hash] - "[message]"

### Handover Notes for Next Session
- **Priority**: [Next feature]
- **Blockers**: [Any blockers]
- **Warnings**: [Gotchas]
- **Environment state**: [Clean/Needs attention]

-->
"""


def create_init_script(tech_stack: str) -> str:
    """Create init.sh for the specified tech stack."""
    tech_info = TECH_STACKS.get(tech_stack, TECH_STACKS["react-fastapi"])
    ports = tech_info["ports"]
    
    port_cleanup = "\n".join(f'    lsof -ti:{p} 2>/dev/null | xargs kill -9 2>/dev/null || true' for p in ports)
    
    if tech_stack == "react-fastapi":
        server_setup = '''
# Backend (FastAPI)
if [ -d "backend" ]; then
    echo "🐍 Setting up Python backend..."
    cd backend
    [ ! -d "venv" ] && python3 -m venv venv
    source venv/bin/activate
    pip install -q -r requirements.txt 2>/dev/null || pip install -r requirements.txt
    echo "🚀 Starting backend..."
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload > /tmp/backend.log 2>&1 &
    cd ..
fi

# Frontend (React/Vite)
if [ -d "frontend" ]; then
    echo "⚛️  Setting up React frontend..."
    cd frontend
    npm install --silent 2>/dev/null || npm install
    echo "🚀 Starting frontend..."
    npm run dev > /tmp/frontend.log 2>&1 &
    cd ..
fi'''
        status = '''
echo "   Frontend:  http://localhost:5173"
echo "   Backend:   http://localhost:8000"
echo "   API Docs:  http://localhost:8000/docs"'''

    elif tech_stack == "nextjs":
        server_setup = '''
echo "⚛️  Setting up Next.js..."
npm install --silent 2>/dev/null || npm install
echo "🚀 Starting Next.js..."
npm run dev > /tmp/app.log 2>&1 &'''
        status = 'echo "   App: http://localhost:3000"'

    elif tech_stack == "python":
        server_setup = '''
echo "🐍 Setting up Python..."
[ ! -d "venv" ] && python3 -m venv venv
source venv/bin/activate 2>/dev/null || true
pip install -q -r requirements.txt 2>/dev/null || pip install -r requirements.txt
echo "🚀 Starting Python app..."
python main.py > /tmp/app.log 2>&1 &'''
        status = 'echo "   App: http://localhost:8000"'

    else:  # node
        server_setup = '''
echo "📦 Setting up Node.js..."
npm install --silent 2>/dev/null || npm install
echo "🚀 Starting Node.js..."
npm run dev > /tmp/app.log 2>&1 &'''
        status = 'echo "   App: http://localhost:3000"'

    return f'''#!/bin/bash
# {tech_info["description"]} - Development Environment
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

echo "🔄 Initializing development environment..."
echo ""

# Cleanup stale processes
echo "🧹 Cleaning up..."
{port_cleanup}

# Check if app structure exists
if [ ! -d "backend" ] && [ ! -d "frontend" ] && [ ! -f "package.json" ] && [ ! -f "main.py" ]; then
    echo "⚠️  No app structure detected yet."
    echo "   This is expected for early sessions."
    echo ""
    echo "📋 Git status:"
    echo "   Branch: $(git branch --show-current 2>/dev/null || echo 'N/A')"
    echo "   Commit: $(git log -1 --oneline 2>/dev/null || echo 'N/A')"
    exit 0
fi
{server_setup}

# Wait for servers
echo ""
echo "⏳ Waiting for servers..."
sleep 3

# Status
echo ""
echo "✅ Development environment ready"
echo ""
{status}
echo ""
echo "📋 Git status:"
echo "   Branch: $(git branch --show-current 2>/dev/null || echo 'N/A')"
echo "   Commit: $(git log -1 --oneline 2>/dev/null || echo 'N/A')"
echo ""
echo "📝 Remember: ONE feature per session!"
'''


def create_gitignore() -> str:
    """Create .gitignore content."""
    return """# Dependencies
node_modules/
venv/
.venv/
__pycache__/
*.pyc

# Build
dist/
build/
.next/
out/

# Environment
.env
.env.local
.env.*.local

# IDE
.idea/
.vscode/
*.swp

# OS
.DS_Store
Thumbs.db

# Logs
*.log
/tmp/

# Database
*.db
*.sqlite

# Test
coverage/
.coverage
.pytest_cache/
"""


def init_project(project_name: str, output_path: Path, tech_stack: str) -> None:
    """Initialize a new long-running agent project."""
    
    project_dir = output_path / project_name
    
    if project_dir.exists():
        print(f"❌ Error: Directory already exists: {project_dir}")
        return
    
    print(f"🚀 Creating long-running agent project: {project_name}")
    print(f"   Location: {project_dir}")
    print(f"   Tech: {tech_stack}")
    print()
    
    # Create directory
    project_dir.mkdir(parents=True)
    
    # feature_list.json
    feature_list = create_feature_list(project_name)
    with open(project_dir / "feature_list.json", 'w') as f:
        json.dump(feature_list, f, indent=2)
    print("✅ Created feature_list.json")
    
    # claude-progress.txt
    progress = create_progress_file(project_name, tech_stack)
    with open(project_dir / "claude-progress.txt", 'w') as f:
        f.write(progress)
    print("✅ Created claude-progress.txt")
    
    # init.sh
    init_script = create_init_script(tech_stack)
    init_path = project_dir / "init.sh"
    with open(init_path, 'w') as f:
        f.write(init_script)
    init_path.chmod(init_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    print("✅ Created init.sh")
    
    # .gitignore
    with open(project_dir / ".gitignore", 'w') as f:
        f.write(create_gitignore())
    print("✅ Created .gitignore")
    
    # Git init
    os.chdir(project_dir)
    os.system("git init -q")
    os.system("git add .")
    os.system('git commit -q -m "Initial project scaffold"')
    print("✅ Initialized git repository")
    
    print()
    print(f"✅ Project '{project_name}' created!")
    print()
    print("Next steps:")
    print(f"  1. cd {project_dir}")
    print("  2. Edit feature_list.json with your project's features")
    print("  3. Start coding sessions!")
    print()
    print("Session start:")
    print("  cat claude-progress.txt && cat feature_list.json")


def main():
    parser = argparse.ArgumentParser(
        description="Initialize a new long-running agent project"
    )
    parser.add_argument("project_name", help="Name of the project")
    parser.add_argument("--path", type=Path, default=Path.cwd(), help="Output directory")
    parser.add_argument(
        "--tech", 
        choices=list(TECH_STACKS.keys()), 
        default="react-fastapi",
        help="Tech stack template"
    )
    
    args = parser.parse_args()
    init_project(args.project_name, args.path, args.tech)


if __name__ == "__main__":
    main()
