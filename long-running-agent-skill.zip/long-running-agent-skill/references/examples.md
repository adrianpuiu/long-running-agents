# Examples Reference

Real-world examples of the long-running agent framework in action.

## Example 1: Trading Analytics Dashboard

A full-stack application with 42 features across 10+ sessions.

### Feature List Extract

```json
{
  "project_name": "Trading Analytics Dashboard",
  "total_features": 42,
  "passing_features": 0,
  "features": [
    {
      "id": "F001",
      "category": "infrastructure",
      "priority": "critical",
      "description": "FastAPI backend server starts and responds to health check",
      "steps": [
        "Run python main.py",
        "GET /health returns 200 OK",
        "Response includes version and timestamp"
      ],
      "passes": false
    },
    {
      "id": "F002",
      "category": "infrastructure",
      "priority": "critical",
      "description": "React frontend builds and renders root component",
      "steps": [
        "Run npm run dev",
        "Navigate to http://localhost:5173",
        "App shell renders without errors"
      ],
      "passes": false
    },
    {
      "id": "F019",
      "category": "functional",
      "priority": "critical",
      "description": "Calculate portfolio risk metrics using railpath-finance-toolkit",
      "steps": [
        "GET /api/portfolios/{id}/risk",
        "Returns Sharpe, Sortino, max drawdown, VaR",
        "Uses toolkit functions for calculations"
      ],
      "passes": false
    },
    {
      "id": "F022",
      "category": "functional",
      "priority": "high",
      "description": "Calculate HMM regime states for market data",
      "steps": [
        "POST /api/regime/detect with price series",
        "Returns regime states (bull/bear/neutral)",
        "Returns transition probabilities"
      ],
      "passes": false
    }
  ]
}
```

### Session Progression

| Session | Focus | Features Completed |
|---------|-------|-------------------|
| 1 | Initializer | 0 (scaffold only) |
| 2 | Backend + Frontend skeleton | F001, F002 |
| 3 | Database + Auth | F003, F004, F005 |
| 4 | Protected routes + Login UI | F006, F007 |
| 5 | Portfolio CRUD | F009, F010, F011 |
| 6 | Price integration | F014, F015 |
| 7 | Dashboard UI | F016, F017 |
| 8 | Risk metrics | F019, F020 |
| 9 | Regime detection | F022, F023 |
| 10+ | Trade journal, alerts, polish | F025-F042 |

---

## Example 2: SaaS Starter Kit

A multi-tenant SaaS boilerplate with auth, billing, and admin.

### Initializer Session Output

```markdown
# Claude Progress Log

## Project: SaaS Starter Kit
## Repository: local
## Primary Tech: Next.js 14 + Prisma + PostgreSQL + Stripe

---

## Session 1 - 2025-01-20 14:00 UTC (Initializer)

### Session Type
Initializer session - comprehensive feature extraction

### Work Completed
1. Analyzed SaaS requirements exhaustively
2. Created feature_list.json with 35 features
3. Created init.sh for Next.js + PostgreSQL stack
4. Organized features by priority for MVP path

### Feature Categories Created
- Auth: 6 features (email/password, OAuth, 2FA, sessions)
- Billing: 5 features (Stripe, plans, invoices, usage)
- Multi-tenancy: 4 features (orgs, invites, roles, switching)
- Admin: 4 features (user management, analytics, settings)
- UI: 8 features (dashboard, settings, onboarding)
- Infrastructure: 8 features (API, webhooks, jobs, logging)

### Recommended Session Order
1. F001-F002: Next.js + DB setup
2. F003-F006: Core auth flow
3. F007-F010: Organization/team setup
4. F011-F014: Stripe billing
5. F015-F020: Dashboard UI
6. F021+: Admin, polish, edge cases

### Handover Notes for Next Session
- **Priority**: F001 (Next.js app) + F002 (Prisma schema)
- **Blockers**: Need PostgreSQL running locally or use SQLite for dev
- **Warnings**: Stripe keys needed for billing features (session 4+)
- **Environment state**: Clean scaffold

---
```

### Feature List (Partial)

```json
{
  "features": [
    {
      "id": "F001",
      "category": "infrastructure",
      "priority": "critical",
      "description": "Next.js 14 app with App Router responds to requests",
      "passes": false
    },
    {
      "id": "F003",
      "category": "security",
      "priority": "critical",
      "description": "User can sign up with email and password",
      "dependencies": ["F001", "F002"],
      "passes": false
    },
    {
      "id": "F011",
      "category": "functional",
      "priority": "critical",
      "description": "Stripe checkout creates subscription",
      "dependencies": ["F003", "F007"],
      "passes": false
    },
    {
      "id": "F015",
      "category": "ui",
      "priority": "high",
      "description": "Dashboard shows subscription status and usage",
      "dependencies": ["F011"],
      "passes": false
    }
  ]
}
```

---

## Example 3: CLI Tool with Plugin System

A command-line application with extensible architecture.

### Session 4 Log (Mid-Project)

```markdown
## Session 4 - 2025-01-22 10:30 UTC

### Context Inherited
- Last commit: b7c9e2f - "feat(F006): config file loading"
- Features passing: 6/18
- Known issues: Plugin hot-reload not working

### Session Goal
- F007: Plugin discovery and loading

### Work Completed
1. Implemented plugin directory scanning
2. Created PluginLoader class with validation
3. Added plugin manifest schema (plugin.json)
4. Hooked plugin system into main CLI
5. Created example "hello-world" plugin

### Testing Performed
- [x] CLI starts without plugins → works
- [x] CLI discovers plugins in ~/.myapp/plugins/
- [x] Valid plugin loads and registers commands
- [x] Invalid plugin (bad manifest) shows helpful error
- [x] Plugin commands appear in --help

### Issues Encountered
- Dynamic imports in TypeScript tricky → used require() for plugins
- Plugin isolation needed → each plugin gets own context object

### Files Changed
- `src/plugins/loader.ts` - new PluginLoader class
- `src/plugins/types.ts` - plugin interfaces
- `src/cli.ts` - integrated plugin loading
- `examples/hello-plugin/` - example plugin

### Commits Made
- c4d5e6f - "feat(F007): plugin discovery and loading"

### Handover Notes for Next Session
- **Priority**: F008 - Plugin lifecycle hooks (init, destroy)
- **Blockers**: None
- **Warnings**: Plugins run in same process - no sandbox yet
- **Environment state**: Clean, example plugin works
```

---

## Example Session: Handling Broken State

What to do when you inherit a broken project:

```markdown
## Session 7 - 2025-01-25 09:00 UTC

### Context Inherited
- Last commit: x9y8z7w - "feat(F012): payment processing"
- Features passing: 11/25
- Known issues: "App crashes on startup"

### Session Goal
- Fix broken state before continuing

### Diagnosis
1. Ran `./init.sh` → Backend crashed with DB error
2. Checked /tmp/backend.log → "relation 'payments' does not exist"
3. Previous session added payments code but didn't run migration

### Recovery Steps
1. `cd backend && alembic upgrade head` → Fixed
2. Ran ./init.sh → Both servers start
3. Tested F001-F011 → All still work
4. Tested F012 → Works now

### Work Completed
1. Fixed database migration (was missing)
2. Added migration check to init.sh
3. Verified all passing features still work
4. Documented the issue in progress file

### Lesson Learned
Previous session violated rule: "Leave code in working state"
Added migration step to init.sh to prevent recurrence.

### Handover Notes for Next Session
- **Priority**: F013 - Payment webhooks (was supposed to be this session)
- **Blockers**: None now
- **Warnings**: Always run migrations! Check init.sh has them.
- **Environment state**: Clean, fully recovered
```

---

## Anti-Pattern Examples

### ❌ Bad: Trying to Do Everything

```markdown
## Session 2

### Work Completed
1. Built complete authentication system
2. Created all database models
3. Implemented entire dashboard
4. Added payment integration
5. Built admin panel
6. Set up deployment

### Features: F001-F025 all passing!
```

**Why it's bad:** No way this was properly tested. Features will be broken.

### ❌ Bad: No Handover Notes

```markdown
## Session 5

### Work Completed
1. Fixed some bugs
2. Added new feature

### Commits Made
- abc123 - "updates"
```

**Why it's bad:** Next session has no idea what happened or what to do next.

### ❌ Bad: Editing Feature Descriptions

```json
// Session 1
{ "id": "F005", "description": "User can reset password" }

// Session 3 - WRONG!
{ "id": "F005", "description": "User can reset password via email with 2FA" }
```

**Why it's bad:** Scope creep. If requirements change, add a NEW feature.

### ✅ Good: Scope Change Handling

```json
// Original
{ "id": "F005", "description": "User can reset password", "passes": true }

// New requirement added properly
{ "id": "F005", "description": "User can reset password", "passes": true },
{ "id": "F045", "description": "Password reset requires 2FA confirmation", "passes": false }
```
