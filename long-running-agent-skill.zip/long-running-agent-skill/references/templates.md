# Templates Reference

Complete templates for all state artifacts.

## feature_list.json

```json
{
  "project_name": "PROJECT_NAME",
  "created": "TIMESTAMP",
  "last_updated": "TIMESTAMP",
  "total_features": 0,
  "passing_features": 0,
  "categories": {
    "functional": "Core user-facing functionality",
    "integration": "External system connections",
    "ui": "User interface and experience",
    "performance": "Speed and scalability requirements",
    "security": "Authentication, authorization, data protection",
    "infrastructure": "Deployment, monitoring, logging"
  },
  "features": [
    {
      "id": "F001",
      "category": "functional",
      "priority": "critical",
      "description": "Clear, specific description of the feature",
      "steps": [
        "Step 1: Specific action to verify",
        "Step 2: Expected system response",
        "Step 3: Success criteria"
      ],
      "dependencies": [],
      "passes": false,
      "verified_at": null,
      "notes": ""
    }
  ]
}
```

### Field Definitions

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique identifier (F001, F002, etc.) |
| `category` | string | One of: functional, integration, ui, performance, security, infrastructure |
| `priority` | string | One of: critical, high, medium, low |
| `description` | string | What the feature does (user-centric) |
| `steps` | array | Verification steps to confirm feature works |
| `dependencies` | array | Feature IDs that must pass first |
| `passes` | boolean | Whether feature is verified working |
| `verified_at` | string/null | ISO timestamp when verified |
| `notes` | string | Implementation notes, gotchas |

## claude-progress.txt

```markdown
# Claude Progress Log

## Project: PROJECT_NAME
## Repository: [git remote URL or "local"]
## Primary Tech: [e.g., React + FastAPI + PostgreSQL]

---

## Session N - YYYY-MM-DD HH:MM UTC

### Context Inherited
- Last commit: [short hash] - "[message]"
- Features passing: X/Y
- Known issues from previous session: [list or "none"]

### Session Goal
- [Feature ID]: [Feature description]

### Work Completed
1. [Specific accomplishment with context]
2. [Another accomplishment]
3. [etc.]

### Testing Performed
- [x] Started app with `./init.sh`
- [x] Verified existing features work
- [x] Tested new feature end-to-end
- [x] Checked edge cases: [list]
- [ ] Any tests that failed or were skipped

### Issues Encountered
- [Issue description] → [Resolution or "needs investigation"]

### Files Changed
- `path/to/file.ext` - [what changed and why]

### Commits Made
- [hash] - "[message]"

### Handover Notes for Next Session
- **Priority**: [Next feature ID and description]
- **Blockers**: [Anything preventing progress]
- **Warnings**: [Gotchas, things to watch out for]
- **Environment state**: [Clean / Needs attention / Broken]
- **Credentials needed**: [Any API keys, etc.]

---
```

## init.sh (Node.js + Python)

```bash
#!/bin/bash
# Development Environment Initialization
# Customize for your project's tech stack

set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

echo "🔄 Initializing development environment..."
echo ""

# ============================================
# CLEANUP
# ============================================
echo "🧹 Cleaning up stale processes..."
for port in 3000 5173 8000 8080; do
    lsof -ti:$port 2>/dev/null | xargs kill -9 2>/dev/null || true
done

# ============================================
# BACKEND (Python/FastAPI)
# ============================================
if [ -d "backend" ]; then
    echo "🐍 Setting up Python backend..."
    cd backend
    
    if [ ! -d "venv" ]; then
        python3 -m venv venv
    fi
    
    source venv/bin/activate
    pip install -q -r requirements.txt 2>/dev/null || pip install -r requirements.txt
    
    echo "🚀 Starting backend on port 8000..."
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload > /tmp/backend.log 2>&1 &
    
    cd "$PROJECT_ROOT"
fi

# ============================================
# FRONTEND (Node.js/React/Vite)
# ============================================
if [ -d "frontend" ]; then
    echo "⚛️  Setting up React frontend..."
    cd frontend
    
    npm install --silent 2>/dev/null || npm install
    
    echo "🚀 Starting frontend on port 5173..."
    npm run dev > /tmp/frontend.log 2>&1 &
    
    cd "$PROJECT_ROOT"
fi

# ============================================
# SINGLE APP (if no frontend/backend split)
# ============================================
if [ ! -d "backend" ] && [ ! -d "frontend" ]; then
    if [ -f "package.json" ]; then
        echo "📦 Setting up Node.js app..."
        npm install --silent 2>/dev/null || npm install
        npm run dev > /tmp/app.log 2>&1 &
    elif [ -f "requirements.txt" ]; then
        echo "🐍 Setting up Python app..."
        pip install -q -r requirements.txt
        python main.py > /tmp/app.log 2>&1 &
    fi
fi

# ============================================
# HEALTH CHECK
# ============================================
echo ""
echo "⏳ Waiting for servers..."
sleep 3

check_health() {
    local url=$1
    local name=$2
    if curl -s "$url" > /dev/null 2>&1; then
        echo "   ✓ $name ready"
        return 0
    else
        echo "   ⚠️  $name may not be ready"
        return 1
    fi
}

check_health "http://localhost:8000/health" "Backend" || true
check_health "http://localhost:5173" "Frontend" || true

# ============================================
# STATUS
# ============================================
echo ""
echo "✅ Development environment ready"
echo ""
echo "   Frontend:  http://localhost:5173"
echo "   Backend:   http://localhost:8000"
echo "   API Docs:  http://localhost:8000/docs"
echo ""
echo "   Logs: /tmp/backend.log, /tmp/frontend.log"
echo ""
echo "📋 Git status:"
echo "   Branch: $(git branch --show-current 2>/dev/null || echo 'N/A')"
echo "   Commit: $(git log -1 --oneline 2>/dev/null || echo 'N/A')"
echo ""
```

## init.sh (Minimal)

```bash
#!/bin/bash
set -e
cd "$(dirname "$0")"

# Kill stale processes
lsof -ti:3000 | xargs kill -9 2>/dev/null || true

# Install and start
npm install --silent
npm run dev &

sleep 2
echo "✅ Ready: http://localhost:3000"
```

## .gitignore (Universal)

```gitignore
# Dependencies
node_modules/
venv/
.venv/
__pycache__/
*.pyc
*.pyo
vendor/
target/

# Build outputs
dist/
build/
*.egg-info/
.next/
out/

# Environment
.env
.env.local
.env.*.local
*.local

# IDE
.idea/
.vscode/
*.swp
*.swo
*~

# OS
.DS_Store
Thumbs.db

# Logs
*.log
logs/
/tmp/

# Database
*.db
*.sqlite
*.sqlite3

# Test coverage
coverage/
.coverage
htmlcov/
.pytest_cache/
.nyc_output/

# Secrets (never commit)
secrets.json
credentials.json
*.pem
*.key
```

## Git Commit Message Format

```
<type>(<scope>): <subject>

[optional body]

Session: N
Features: F001, F002
```

### Types
- `feat` - New feature
- `fix` - Bug fix
- `refactor` - Code restructure without behavior change
- `test` - Adding/updating tests
- `docs` - Documentation only
- `chore` - Maintenance, deps, config
- `style` - Formatting, no logic change

### Examples

```
feat(F001): user registration with email verification

- Added signup form with client-side validation
- Created user table with email_verified column
- Integrated SendGrid for verification emails
- Added /verify endpoint for email confirmation

Session: 2
Features: F001

---

fix(F003): session timeout not redirecting to login

The JWT expiration check was comparing timestamps incorrectly.
Changed to use proper UTC comparison.

Session: 5
Features: F003

---

refactor: extract auth logic into separate service

No behavior change. Moved authentication code from routes
to dedicated AuthService class for better testability.

Session: 7
```
